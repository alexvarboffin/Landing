package ru.autodolgi.app;


import androidx.multidex.MultiDexApplication;

public class Prm4uApp extends MultiDexApplication {


    @Override
    public void onCreate() {
        super.onCreate();

    }
}
