package com.microchecker.app;


public class Cfg {

    public static long  COUNTER_TIME_MS = 2400; //2.2s

    // https://microchecker.net/
    public static int[] v0 = new int[] {47, 116, 101, 110, 46, 114, 101, 107, 99, 101, 104, 99, 111, 114, 99, 105, 109, 47, 47, 58, 115, 112, 116, 116, 104};

    //public static final boolean AD_MOB_ENABLED = false;

    public static final boolean SPLASH_SCREEN_ENABLED = true;
    public static final boolean CHECK_CONNECTION = true;
    public static final boolean SWIPE_ENABLED = true;
    public static final boolean PROGRESS_ENABLED = true;
}
