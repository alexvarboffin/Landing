package com.microchecker.app;


import androidx.multidex.MultiDexApplication;

public class MicroApp extends MultiDexApplication {


    @Override
    public void onCreate() {
        super.onCreate();

    }
}
